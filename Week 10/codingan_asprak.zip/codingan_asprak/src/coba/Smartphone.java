package coba;

public class Smartphone implements Gadget{
    @Override
    public void dihidupkan() {
        System.out.println("HP menyala");
    }
}
