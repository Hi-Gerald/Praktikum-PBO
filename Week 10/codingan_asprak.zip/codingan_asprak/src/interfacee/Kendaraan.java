package interfacee;

public interface Kendaraan {
    void nyalakanMesin();
    void matikanMesin();
}
