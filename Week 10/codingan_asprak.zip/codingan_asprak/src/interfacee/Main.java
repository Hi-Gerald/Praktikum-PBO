package interfacee;

public class Main {
    public static void main(String[] args) {
        Mobil mobil = new Mobil("Porsche Taycan");
        mobil.nyalakanMesin();
        mobil.matikanMesin();
        mobil.produksiKendaraan();
        mobil.pemilikKendaraan("Gua");
    }
}
