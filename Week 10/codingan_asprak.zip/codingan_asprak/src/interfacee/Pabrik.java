package interfacee;

public interface Pabrik {
    public void produksiKendaraan();
}
